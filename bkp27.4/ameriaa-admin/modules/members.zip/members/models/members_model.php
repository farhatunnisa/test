<?php
/**
* members_model
* 
* This is members model in members Module 
* 
* PHP version 5
* 
* @category   members_model
* @package    members
* @author     SUDHARSHAN MEKALA <sudharshan.mphp@gmail.com>
* @version    1.0
* @license    http://URL name
* @access     public
*/
class members_model extends Model {
    /**
    * Constructor
    * 
    * Here we can load default settings
    */
    public function __construct() {
        parent::__construct();      
    }
    
   /**
    * getmembers()
    * get the members list
    * @access public
    * @return type array()
    */
    public function getmembers() {  
        $tableName = DB_PREFIX.'members';
        $columns = array("$tableName.member_id",
                         "$tableName.first_name",
                         "$tableName.email",
                         "$tableName.country",                         
                         "$tableName.status",
                         "$tableName.member_id"
                        );
        $indexId = '$tableName.member_id';
        $columnOrder = "$tableName.member_id";
        $orderby = "ORDER BY $columnOrder DESC";
        $joinMe = "";
        $condition = " WHERE $tableName.member_id != '' ";
        return $this->db->drawdatatable($tableName, $columns, $indexId, $joinMe,$condition, $orderby);
    }  
    
    /**
     * changeStatus()
     * change members status
     * @param array $data
     * @access public
     * @return boolean
     */
    public function changeStatus($data){
        extract($data);
        $values = array();        
        if($data['statusId'] == 1) {
            $values['status'] = 0;
        } else {
            $values['status'] = 1;
        }
        $id = $data['membersId'];        
        $result = $this->db->update(DB_PREFIX.'members', $values, "`member_id` = $id");
        if($result) {
            return true;
        } else {
            return false;
        }
    }
    
    
    
    public function membersDetails($id) {
        $result = $this->db->find("SELECT * FROM ".DB_PREFIX."members WHERE member_id = '$id'");
        return $result;
    }
    
   
}

/* End of file members_model.php */
/* Location: ./modules/members/models/members_model.php */
?>