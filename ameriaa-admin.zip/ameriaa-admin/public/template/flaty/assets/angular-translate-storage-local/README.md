# bower-angular-translate-storage-local

angular-translate-cookie-local bower package

### Installation

````
$ bower install angular-translate-storage-local
````
