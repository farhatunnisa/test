# bower-angular-translate-storage-cookie

angular-translate-cookie-storage bower package

### Installation

````
$ bower install angular-translate-storage-cookie
````
