<!-- footer -->
    <footer id="footer" class="app-footer" role="footer">
      <div class="wrapper b-t bg-light">
        <span class="pull-right">2.0.1 <a href ui-scroll="app" class="m-l-sm text-muted"><i class="fa fa-long-arrow-up"></i></a></span>
    	&copy; 2015 Copyright.
      </div>
    </footer>
  <!-- / footer -->

</div>

</body>
</html>