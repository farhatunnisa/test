<?php
$local = 2;
if($local == 1){
    $config['googleplus']['application_name'] = '';
    $config['googleplus']['client_id'] = '1023819726520-ppi7fbj5v7t9sfkood3diehesl934oda.apps.googleusercontent.com';
    $config['googleplus']['client_secret'] = 'rfd_rt7--_Yaf_TymRuMev4d';
    $config['googleplus']['redirect_uri'] = 'http://localhost/schooladmitonline/signin/googleLoginSubmit';
    $config['googleplus']['api_key'] = 'AIzaSyBJifqZVafc55j5hQgvTyWmv9Y6j7DebD8';
}else {
    $config['googleplus']['application_name'] = '';
    $config['googleplus']['client_id'] = '1023819726520-adk07gbhufuo2r73d7fqqiouoqt2rnsr.apps.googleusercontent.com';
    $config['googleplus']['client_secret'] = '_E_Xnc65uFS3SxX5uoHk8aqj';
    $config['googleplus']['redirect_uri'] = 'http://www.demo.schooladmit.com/signin/googleLoginSubmit';
    $config['googleplus']['api_key'] = 'AIzaSyBJifqZVafc55j5hQgvTyWmv9Y6j7DebD8';
}

?>
