<?php
/**
* Header_Model
* 
* This is header model in Header Module 
* 
* PHP version 5
* 
* @category   Header_Model
* @package    Search
* @author Original Author <sankar.g@siriinnovations.com>
* @version    1.0
* @license    http://URL name
* @access     public
*/
class Header_Model extends Model {
    
    /*
    * Constructor
    */
    public function __construct() {
        parent::__construct();       
    }
    
}

/* End of file header_model.php */
/* Location: ./models/header_model.php */
?>
