<?php
/*
 * This is Index filr in view
 */
         
echo THEMEDIR;

?>
