<?php
ini_set('max_execution_time', 1800);
/**
 *  By default we have include config file
 * in this file conain default controller
 * you need change this file go to config and change there
 */
 
require_once 'libs/config.php';
/**
 * Wrapper file is mainly using manage all core files
 */
require_once 'core/Wrapper.php';
?>